﻿using Microsoft.EntityFrameworkCore;
using UserManagementApi.Model;

namespace UserManagementApi.Data
{
    public class ApplicationDbContext: DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<User> Users { get; set; }
        public DbSet<Userd> UsersD { get; set; }
        public DbSet<RefreshToken> RefreshTokens { get; set; }
    }
}
