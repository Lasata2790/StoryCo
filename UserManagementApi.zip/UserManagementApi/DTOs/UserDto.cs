﻿namespace UserManagementApi.DTOs
{
    public class Userdto
    {
        public int Id { get; set; }
        public string Email { get; set; }
    }
}
