﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task3_StoryCo.Models;

namespace Task3_StoryCo.Controllers
{
    public class CompanyController : Controller
    {
        private readonly ApplicationDbContext _context;
        public CompanyController(ApplicationDbContext context)
        {
            _context = context;
        }


        // GET: CompanyController
        public ActionResult Index()
        {
            var Company = _context.Company.ToList();
            return View(Company);
        }


        // GET: CompanyController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: CompanyController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CompanyController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Company company)
        {
            if (ModelState.IsValid)
            {
                _context.Company.Add(company);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(company);
        }
        // GET: CompanyController/Edit/5
        // Edit - GET
        public IActionResult Edit(int id)
        {
            var company = _context.Company.Find(id);
            return View(company);
        }

        // Edit - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Company company)
        {
            if (ModelState.IsValid)
            {
                _context.Company.Update(company);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(company);
        }
        // GET: CompanyController/Delete/5
        // Delete
        public IActionResult Delete(int id)
        {
            var company = _context.Company.Find(id);
            _context.Company.Remove(company);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        // POST: CompanyController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
