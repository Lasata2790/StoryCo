﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Task3_StoryCo.Models
{
    public class Company
    {
        [Key] // Id named column is always the pk
        public int Id { get; set; }
        public string CompanyName { get; set; }
        public string CompanyAddress { get; set; }
        public DateTime EstablishedDate { get; set; }
        public bool Status { get; set; }
    }

}
