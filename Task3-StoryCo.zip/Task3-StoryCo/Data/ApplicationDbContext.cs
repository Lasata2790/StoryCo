﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Task3_StoryCo.Models;

public class ApplicationDbContext : DbContext
{
    // for constructors: ct tab tab
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {

    }
    public DbSet<Company> Company { get; set; }
}